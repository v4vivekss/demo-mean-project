export class SolarHeater{
    solarHeaterId : number;
    installationDate : Date;
    message: string;
}