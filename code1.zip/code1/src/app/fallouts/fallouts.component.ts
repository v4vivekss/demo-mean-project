import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fallouts',
  templateUrl: './fallouts.component.html',
  styleUrls: ['./fallouts.component.css']
})
export class FalloutsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
