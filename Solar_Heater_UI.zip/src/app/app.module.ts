import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AllocateComponent } from './allocate/allocate.component';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import {AllocateServiceService} from './allocate/allocate-service.service';
import { DaysCountPipe } from './days-count.pipe';
import { SearchComponent } from './search/search.component';
import { SearchService } from './search/search.service';
import { TesterComponent } from './tester/tester.component';
import { ResultPipe } from './tester/result.pipe';
 

@NgModule({
  declarations: [
    AppComponent,
    AllocateComponent,
    DaysCountPipe,
    SearchComponent,
    TesterComponent,
    ResultPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [AllocateServiceService,SearchService],
  bootstrap: [AppComponent],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
