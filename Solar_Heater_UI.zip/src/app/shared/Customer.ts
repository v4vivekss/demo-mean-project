export class Customer{
    customerId : number;
    name : string;
    location : string;
    purchase:String;
    install:String;
    message: string;
    distributorName : string;
    purchaseDate : Date;
}