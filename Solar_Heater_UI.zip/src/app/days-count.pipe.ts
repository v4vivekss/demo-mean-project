import { Pipe, PipeTransform } from '@angular/core';
// import { DatePipe } from '@angular/common';

@Pipe({
  name: 'daysCount'
})
export class DaysCountPipe implements PipeTransform {

  transform(value: any, args?: any): string {
    let valueDate = new Date(value);
    let today = new Date();
    let duration = valueDate.getTime() - today.getTime();
    duration = Math.round((duration / (24*60*60*1000)));
    // let duration = valueDate-today
    return duration.toString();
  }
}
