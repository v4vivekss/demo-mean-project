var express = require('express');
var routing = express.Router();
var allocateService = require('../service/allocate')
var Customer = require('../model/customer')

routing.post('/allocate/:distributor', (req, res, next) => {
    var assign = new Customer(req.body);
    allocateService.allocate(req.params.distributor, assign).then((custObj) => {
        res.json({ "message": "Solar heater " + req.params.distributor + " successfully purchased by customer id" + custObj.customerId, "purchase":custObj.purchaseDate,"install":custObj.installationDate })
    }).catch(function (err) {
        next(err);
    })
})

routing.get('/findService/:location', (req, res, next) => {
    allocateService.fetchDetails(req.params.location).then((data) => {
        res.send(data)
    }).catch((err) => {
        next(err);
    })
})




module.exports = routing;