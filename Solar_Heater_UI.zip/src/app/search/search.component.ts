import { Component, OnInit } from '@angular/core';
import { SearchService } from './search.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  errorMessage: String;
  successData: String[];
  location: String;

  constructor(private service: SearchService) { }

  ngOnInit() {
  }

  displayDistributors() {
    this.errorMessage = null;
    this.successData = null;
    this.service.findDistributor(this.location).subscribe(
      response => this.successData = response,
      err => this.errorMessage = err.error.message
    )
  }
}
