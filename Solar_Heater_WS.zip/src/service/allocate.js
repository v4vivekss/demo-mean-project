let allocateModel = require('../model/allocate')
let validator = require('../utilities/validator');

let allocateService = {}

allocateService.allocate = (distName, customerObj) => {
    validator.validateDate(customerObj.purchaseDate, customerObj.installationDate)
    validator.validateDistributor(distName)

    return allocateModel.allocateHeater(distName, customerObj).then((custObj) => {
        return custObj;
    })
}

allocateService.fetchDetails = (location) => {
    return allocateModel.fetchDetails(location).then((data) => {
        let dataArr = []
        data.forEach(_ => {
            dataArr.push(_.distributorName)
        })
        return dataArr;
    })
}

module.exports = allocateService;