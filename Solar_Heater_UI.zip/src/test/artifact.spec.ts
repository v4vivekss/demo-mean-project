import { async, ComponentFixture, TestBed, inject, fakeAsync, tick } from '@angular/core/testing';
import { ReactiveFormsModule, FormBuilder, FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable, of, throwError } from 'rxjs';
import { AllocateComponent } from '../app/allocate/allocate.component';
import { AllocateServiceService } from '../app/allocate/allocate-service.service';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { SolarHeater } from 'src/app/shared/SolarHeater';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { AppComponent } from 'src/app/app.component';
import { routes } from '../app/app-routing.module';
import { SearchComponent } from 'src/app/search/search.component';
import { SearchService } from 'src/app/search/search.service';
import { TesterComponent } from 'src/app/tester/tester.component';
import {DaysCountPipe} from 'src/app/days-count.pipe'


class MockAllocationService {
    allocate(): Observable<SolarHeater> { return new Observable(); }
}

describe('Testing_AllocateComponent', () => {
    var component: AllocateComponent;
    var fixture: ComponentFixture<AllocateComponent>;
    var allocateService


    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, ReactiveFormsModule, HttpClientModule],
            declarations: [AllocateComponent,DaysCountPipe],
            providers: [{ provide: AllocateServiceService, useClass: MockAllocationService }]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AllocateComponent);
        component = fixture.componentInstance;
        allocateService = TestBed.get(AllocateServiceService)
        fixture.detectChanges();
        jasmine.MAX_PRETTY_PRINT_DEPTH = 2
    });

    it('AllocateComponent should be created', () => {
        expect(component).toBeTruthy();
    });

    it('AllocateComponent: Missing/Incorrect ids', () => {
        component.allocateForm.controls['distributorName'].markAsTouched();
        component.allocateForm.controls['name'].markAsTouched();
        component.allocateForm.controls['purchaseDate'].markAsDirty();
        component.allocateForm.controls['installationDate'].markAsDirty();
        component.allocateForm.controls['location'].markAsTouched();
        fixture.detectChanges();

        let idList: string[] = ["distributorName", "distributorNameErr", "purchaseDate", "name", "nameErr", "purchaseDateErr", "installationDate", "installationDateErr", "location", "locationErr"];
        idList.forEach(element => {
            let select = fixture.debugElement.query(By.css(`#${element}`));
            expect(select).not.toBeNull()
        });
    })

    it('AllocateComponent: Missing FormControl property', () => {
        let allocateForm: DebugElement = fixture.debugElement.query(By.css('form'));
        let distName: DebugElement = fixture.debugElement.query(By.css('#distributorName'));
        let custName: DebugElement = fixture.debugElement.query(By.css('#name'));
        let pDate: DebugElement = fixture.debugElement.query(By.css('#purchaseDate'));
        let iDate: DebugElement = fixture.debugElement.query(By.css('#installationDate'));
        let custId: DebugElement = fixture.debugElement.query(By.css('#location'))

        expect(allocateForm.attributes['ng-reflect-form']).toBeTruthy();
        expect(distName.attributes['formControlName']).toBe('distributorName');
        expect(custName.attributes['formControlName']).toBe('name');
        expect(pDate.attributes['formControlName']).toBe('purchaseDate');
        expect(iDate.attributes['formControlName']).toBe('installationDate');
        expect(custId.attributes['formControlName']).toBe('location');
    })

    it('AllocateComponent: Configuring allocateSolar() method', () => {
        spyOn(allocateService, 'allocate').and.returnValue(of({ message: 'Success message is populated' }));
        component.allocateSolar();
        expect(component.errorMessage).toBe(null);
        expect(component.successMessage).toEqual('Success message is populated');
        expect(component.allocateSolar.length).toEqual(0);
    })

    it('AllocateComponent: Missing dependencies', inject([AllocateServiceService, FormBuilder], (service: AllocateServiceService, fb: FormBuilder) => {
        expect(service).not.toBeNull('service not injected'); //modified
        expect(fb).not.toBeNull('Form builder not injected');
    }));
})


describe('Testing_AllocateService', () => {

    let mockResponse = '{"message":"Pass"}';
    var data = { "distributorName": "A4Solar" }
    let httpMock: HttpTestingController;
    let dataService: AllocateServiceService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [AllocateServiceService]
        });
        httpMock = TestBed.get(HttpTestingController);
        dataService = TestBed.get(AllocateServiceService);
    });

    it('AllocateService: Missing dependencies', inject([HttpClient], (http: HttpClient) => {
        expect(http).not.toBeNull('HttpClient should be provided');
    }))


    it('AllocateService: Configured correctly', inject([HttpTestingController, AllocateServiceService], (httpMock, service) => {
        service.allocate(data).subscribe((response) => {
            expect(response).toBe(mockResponse)
        })
        const mockReq = httpMock.expectOne('http://localhost:2040/allocate/' + data.distributorName);
        mockReq.flush(mockResponse);
        httpMock.verify();
    }))

    it('AllocateService: Configure HTTP method', inject([HttpClient], (http: HttpClient) => {
        const spy = spyOn(http, "post").and.returnValue(of({ message: 'Success' }));
        dataService.allocate(mockResponse);
        expect(spy).toHaveBeenCalled();
    }))
})

describe('Testing_App', () => {
    let component: AppComponent;
    let fixture: ComponentFixture<AppComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule,HttpClientModule],
            declarations: [AppComponent,TesterComponent],
        }).compileComponents();
    }));

    it('AppComponent: Required configuration', () => {
        fixture = TestBed.createComponent(AppComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        expect(component).toBeTruthy();
    })

    it('AppRouting: Configuring all routes', () => {
        expect(routes.length).toEqual(3);
    })
})

class SearchServiceStub {
    findDistributor() { new Observable(); }
}

describe('Testing_SearchComponent', () => {
    let component: SearchComponent;
    let fixture: ComponentFixture<SearchComponent>;
    let searchService;
    // let searchComponent;

    beforeEach(async(()=>{
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, FormsModule],
            declarations:[SearchComponent],
            providers: [{ provide: SearchService, useClass: SearchServiceStub }]
        })
        .compileComponents();
    }))

    beforeEach(() => {
        fixture = TestBed.createComponent(SearchComponent);
        component = fixture.componentInstance;
        searchService = TestBed.get(SearchService)
        fixture.detectChanges();
        jasmine.MAX_PRETTY_PRINT_DEPTH = 2
      });

      it('SearchComponent: Configured correctly', fakeAsync(()=>{
        let testValue = "Bangalore"
        component.location = testValue;
        fixture.detectChanges();
        tick();
        expect(fixture.debugElement.query(By.css('input')).nativeElement.value).toEqual(testValue)
      }));

      it('SearchComponent: Configuring displayDistributors() method',()=>{
        spyOn(searchService, 'findDistributor').and.returnValue(throwError({error:{ message: 'Error message is populated' }}));
        component.displayDistributors();
        expect(component.successData).toBe(null);
        expect(component.errorMessage).toEqual('Error message is populated');
      })
})

describe('Testing_SearchService',()=>{
    let mockResponse = ["Loc1","Loc2"];
    let httpMock: HttpTestingController;
    let dataService: SearchService;
    let location:string ="Bangalore"
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [SearchService]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [SearchService]
        });
        httpMock = TestBed.get(HttpTestingController);
        dataService = TestBed.get(SearchService);
    });

    it('SearchService: Missing dependencies', inject([HttpClient], (http: HttpClient) => {
        expect(http).not.toBeNull('HttpClient should be provided');
    }))

    it('SearchService: Configured correctly', inject([HttpTestingController, SearchService], (httpMock, service) => {
        service.findDistributor(location).subscribe((response) => {
            expect(response).toBe(mockResponse)
        })
        const mockReq = httpMock.expectOne('http://localhost:2040/findService/' + location);
        mockReq.flush(mockResponse);
        httpMock.verify();
    }))

    it('SearchService: Configure HTTP method', inject([HttpClient], (http: HttpClient) => {
        const spy = spyOn(http, "get").and.returnValue(of({ message: 'Success' }));
        dataService.findDistributor(mockResponse);
        expect(spy).toHaveBeenCalled();
    }))

})





