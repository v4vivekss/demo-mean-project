const express = require('express');
const bodyParser = require('body-parser');
const router = require('./routes/routing');
const myErrorLogger = require('./utilities/errorlogger');
const myRequestLogger = require('./utilities/requestlogger');
const tester = require("../parserModule/parser").reportGenerator
const create = require("./model/dbsetup")
const cors = require('cors');
const app = express();

var allow = true;

app.use(cors());
app.use(bodyParser.json());
app.use(myRequestLogger);
app.use('/', router);

//Donot remove the below code
app.get('/test', (req, res, next) => {
    if (allow) {
        allow = false;
        tester().then((data) => {
            console.log("--- Verification Completed ---");
            allow = true;
            res.send(data)
        }).catch((err) => {
            allow = true;
            next(err)
        })
    }
})

app.get('/setupDb', (req, res, next) => {
    create.setupDb().then((data) => {
        res.send(data)
        console.log("Data sent")
    }).catch((err) => {
        next(err)
    })
})

app.use(myErrorLogger);

app.listen(2040);
console.log("Server listening in port 2040");

module.exports = app;