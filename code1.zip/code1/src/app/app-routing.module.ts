import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { RedComponent } from "./red/red.component";
import { BlueComponent } from "./blue/blue.component";
import { ConfigComponent } from "./config/config.component";
import { FalloutsComponent } from "./fallouts/fallouts.component";
import { SearchComponent } from "src/app/search/search.component";
import { GreenComponent } from "src/app/green/green.component";
import { OrangeComponent } from "./orange/orange.component";

const routes: Routes = [
  { path: "red", component: RedComponent },
  { path: "blue", component: BlueComponent },
  { path: "green", component: GreenComponent },
  { path: "search", component: SearchComponent },
  { path: "orange", component: OrangeComponent },
  { path: "fallouts", component: FalloutsComponent },
  { path: "config", component: ConfigComponent },
  { path: "**", redirectTo: "#" }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
