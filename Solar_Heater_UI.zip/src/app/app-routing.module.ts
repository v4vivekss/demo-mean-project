import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllocateComponent } from './allocate/allocate.component';
import { SearchComponent } from './search/search.component';
// import the neccessary files

export const routes: Routes = [
  // write the route path's and thier corresponding components here
  {path: 'allocate',component:AllocateComponent},
  {path:'search',component:SearchComponent},
  {path: '**', redirectTo:'allocate' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
