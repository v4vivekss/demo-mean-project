import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { AllocateServiceService } from './allocate-service.service';

@Component({
  selector: 'app-allocate',
  templateUrl: './allocate.component.html',
  styleUrls: ['./allocate.component.css']
})
export class AllocateComponent implements OnInit {

  errorMessage: String;
  successMessage: String;
  installDate: Date;
  purcahseDate: Date;

  constructor(private fb: FormBuilder, private allocateService: AllocateServiceService) { }

  allocateForm = this.fb.group({
    distributorName: ["", Validators.required],
    name:["",[Validators.required,Validators.minLength(3)]],
    purchaseDate: ["", [Validators.required, validateDate]],
    installationDate: ["", [Validators.required, validateDate]],
    location: ["", [Validators.required, Validators.pattern(/[A-z]{3,}/)]]
  })
  ngOnInit() {
  }

  allocateSolar() {
    this.errorMessage = null;
    this.successMessage = null;
    this.installDate = null;
    this.purcahseDate = null;
    this.allocateService.allocate(this.allocateForm.value)
      .subscribe(response => {
        this.successMessage = response.message;
        this.installDate = new Date(response.install);
        this.purcahseDate = new Date(response.purchase);
        console.log(response.install,response.purchase)
      },
        err =>
          this.errorMessage = err.error.message);
  }

}

function validateDate(date: FormControl) {
  /* Code the Custom validator here */
  return (new Date(date.value) >= new Date()) ? null : { dateError: { message: "Entered date cannot be a past date" } }
}
